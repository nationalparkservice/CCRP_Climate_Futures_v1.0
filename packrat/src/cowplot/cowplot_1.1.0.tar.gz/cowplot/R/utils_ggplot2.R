# code that needed to be copied from ggplot2

# @keyword internal
is.waive <- function(x) inherits(x, "waiver")
