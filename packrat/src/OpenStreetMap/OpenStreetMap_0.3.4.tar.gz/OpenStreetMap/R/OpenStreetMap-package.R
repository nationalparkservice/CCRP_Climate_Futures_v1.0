



#' The United States
#'
#' @name states
#' @docType data
#' @keywords data
NULL

#' Places of interest in Los Angeles
#'
#' @name LA_places
#' @docType data
#' @keywords data
NULL

