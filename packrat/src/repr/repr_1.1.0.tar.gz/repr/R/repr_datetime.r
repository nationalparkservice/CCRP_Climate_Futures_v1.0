# https://developer.mozilla.org/en-US/docs/Web/HTML/Element/time

#repr_html.POSIXlt <- 
#repr_html.POSIXct <- 
#repr_html.date <- 
#repr_html.dates <- 
