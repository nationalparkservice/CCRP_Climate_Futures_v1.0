#' Deprecated tmap functions
#' 
#' Since version 2.0, tmap function names are prefixed with a tm_ or tmap_. Therefore, function names used by tmap 1.x such as \code{animation_tmap} have been renamed to \code{tmap_animation}.
#' 
#' \itemize{
#'  \item \code{animation_tmap}: replaced by \code{\link{tmap_animation}}
#'  \item \code{save_tmap}: replaced by \code{\link{tmap_save}}
#'  \item \code{style_catalogue}: replaced by \code{\link{tmap_style_catalogue}}
#'  \item \code{style_catalog}: replaced by \code{\link{tmap_style_catalog}}
#'  \item \code{last_map}: replaced by \code{\link{tmap_last}}
#'  \item \code{tm_style_white}: replaced by \code{\link{tm_style}("white")}
#'  \item \code{tm_style_gray}: replaced by \code{\link{tm_style}("gray")}
#'  \item \code{tm_style_grey}: replaced by \code{\link{tm_style}("grey")}
#'  \item \code{tm_style_natural}: replaced by \code{\link{tm_style}("natural")}
#'  \item \code{tm_style_cobalt}: replaced by \code{\link{tm_style}("cobalt")}
#'  \item \code{tm_style_col_blind}: replaced by \code{\link{tm_style}("col_blind")}
#'  \item \code{tm_style_albatross}: replaced by \code{\link{tm_style}("albatross")}
#'  \item \code{tm_style_beaver}: replaced by \code{\link{tm_style}("beaver")}
#'  \item \code{tm_style_bw}: replaced by \code{\link{tm_style}("bw")}
#'  \item \code{tm_style_classic}: replaced by \code{\link{tm_style}("classic")}
#'  \item \code{tm_format_World}: replaced by \code{\link{tm_format}("World")}
#'  \item \code{tm_format_World_wide}: replaced by \code{\link{tm_format}("World_wide")}
#'  \item \code{tm_format_NLD}: replaced by \code{\link{tm_format}("NLD")}
#'  \item \code{tm_format_NLD_wide}: replaced by \code{\link{tm_format}("NLD_wide")}
#'  \item \code{tm_format_Europe}: not used anymore, since the dataset Europe is no longer maintained
#'  \item \code{tm_format_Europe2}: not used anymore, since the dataset Europe is no longer maintained
#'  \item \code{tm_format_Europe_wide}: not used anymore, since the dataset Europe is no longer maintained
#' }
#' 
#' @rdname deprecated_functions
#' @name deprecated_functions
NULL
