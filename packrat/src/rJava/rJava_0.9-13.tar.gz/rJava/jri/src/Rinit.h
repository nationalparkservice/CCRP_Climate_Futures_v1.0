#ifndef __R_INIT__H__
#define __R_INIT__H__

int initR(int argc, char **argv);
void initRinside();

#endif
