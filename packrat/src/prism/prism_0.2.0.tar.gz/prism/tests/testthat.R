library(testthat)
suppressPackageStartupMessages(library(prism))

test_check("prism")
