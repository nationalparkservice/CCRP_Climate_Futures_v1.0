## load dependencies
library(testthat)
suppressPackageStartupMessages(library(stars))

## test package
test_check("stars")
