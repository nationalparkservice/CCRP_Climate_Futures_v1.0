library(testthat)
library(cft)

test_check("cft")
