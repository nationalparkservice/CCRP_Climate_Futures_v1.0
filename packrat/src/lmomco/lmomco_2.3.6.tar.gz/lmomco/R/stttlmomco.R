"stttlmomco" <- function(f,para) {
    return(tttlmomco(f,para)/cmlmomco(f=0,para))
}
