"prob2T" <-
function(f) {
    if(! check.fs(f)) return()
    return(1/(1-f))
}
