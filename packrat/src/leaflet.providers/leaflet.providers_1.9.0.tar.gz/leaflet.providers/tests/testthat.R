library(testthat)
library(leaflet.providers)

test_check("leaflet.providers")
